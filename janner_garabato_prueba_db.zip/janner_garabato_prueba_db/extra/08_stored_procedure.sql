-- =====================================================================
-- Puntos extra: Procedimiento almacenado
-- Purpose: Query suppliers by id; if NULL is sent, return all suppliers
-- Engine: PostgreSQL (implemented as a function, since PostgreSQL
-- functions are the standard mechanism to return result sets;
-- functionally equivalent to a stored procedure with an OUT cursor)
-- =====================================================================

CREATE OR REPLACE FUNCTION riwi_get_supplier(p_supplier_id INTEGER DEFAULT NULL)
RETURNS TABLE (
    supplier_id     INTEGER,
    supplier_name   VARCHAR,
    city_name       VARCHAR
) AS $$
BEGIN
    IF p_supplier_id IS NULL THEN
        RETURN QUERY
        SELECT s.supplier_id, s.supplier_name, ci.city_name
        FROM riwi_supplier s
        JOIN riwi_city ci ON ci.city_id = s.city_id
        ORDER BY s.supplier_name;
    ELSE
        RETURN QUERY
        SELECT s.supplier_id, s.supplier_name, ci.city_name
        FROM riwi_supplier s
        JOIN riwi_city ci ON ci.city_id = s.city_id
        WHERE s.supplier_id = p_supplier_id;
    END IF;
END;
$$ LANGUAGE plpgsql;

-- Example usage:
-- SELECT * FROM riwi_get_supplier(1);      -- one supplier
-- SELECT * FROM riwi_get_supplier(NULL);   -- all suppliers
-- SELECT * FROM riwi_get_supplier();        -- all suppliers (default NULL)
