-- =====================================================================
-- Puntos extra: Vistas SQL
-- Engine: PostgreSQL
-- =====================================================================

-- View 1: Current stock available per product (operative view)
CREATE OR REPLACE VIEW riwi_vw_stock_per_product AS
SELECT
    p.product_id,
    p.product_name,
    c.category_name,
    COALESCE(SUM(CASE WHEN m.movement_type = 'IN'  THEN m.quantity END), 0) AS total_in,
    COALESCE(SUM(CASE WHEN m.movement_type = 'OUT' THEN m.quantity END), 0) AS total_out,
    COALESCE(SUM(CASE WHEN m.movement_type = 'IN'  THEN m.quantity END), 0)
        - COALESCE(SUM(CASE WHEN m.movement_type = 'OUT' THEN m.quantity END), 0) AS available_stock
FROM riwi_product p
JOIN riwi_category c ON c.category_id = p.category_id
LEFT JOIN riwi_inventory_movement m ON m.product_id = p.product_id
GROUP BY p.product_id, p.product_name, c.category_name;

-- View 2: Purchase summary per supplier (analytical view)
CREATE OR REPLACE VIEW riwi_vw_purchases_per_supplier AS
SELECT
    s.supplier_id,
    s.supplier_name,
    ci.city_name AS supplier_city,
    COUNT(pu.purchase_id)            AS purchase_orders,
    SUM(pu.quantity)                 AS total_units_purchased,
    SUM(pu.quantity * pu.unit_price) AS total_amount_purchased
FROM riwi_supplier s
JOIN riwi_city ci ON ci.city_id = s.city_id
LEFT JOIN riwi_purchase pu ON pu.supplier_id = s.supplier_id
GROUP BY s.supplier_id, s.supplier_name, ci.city_name;

-- Example usage:
-- SELECT * FROM riwi_vw_stock_per_product ORDER BY available_stock DESC;
-- SELECT * FROM riwi_vw_purchases_per_supplier ORDER BY total_amount_purchased DESC;
