-- =====================================================================
-- RiwiSupply S.A.S. - Relational Database
-- Script: 05_update.sql
-- Purpose: Modify information of an existing supplier
-- Engine: PostgreSQL
-- =====================================================================

-- Example: the supplier "Industriales S.A.S." changes its trade name
-- and relocates its registered city to Barranquilla (already existing).

UPDATE riwi_supplier
SET supplier_name = 'Industriales de Colombia S.A.S.',
    city_id = (SELECT city_id FROM riwi_city WHERE city_name = 'Barranquilla')
WHERE supplier_name = 'Industriales S.A.S.';

-- Verify the change
SELECT supplier_id, supplier_name, city_id
FROM riwi_supplier
WHERE supplier_name = 'Industriales de Colombia S.A.S.';
