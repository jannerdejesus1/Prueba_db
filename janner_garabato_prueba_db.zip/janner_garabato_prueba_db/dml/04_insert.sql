-- =====================================================================
-- RiwiSupply S.A.S. - Relational Database
-- Script: 04_insert.sql
-- Purpose: Register a new supplier and its associated product
-- Engine: PostgreSQL
-- =====================================================================

-- 1. Make sure the city exists (insert only if it is new)
INSERT INTO riwi_city (city_name)
VALUES ('Monteria')
ON CONFLICT (city_name) DO NOTHING;

-- 2. Register the new supplier
INSERT INTO riwi_supplier (supplier_name, city_id)
VALUES (
    'Ferreteria del Sinu S.A.S.',
    (SELECT city_id FROM riwi_city WHERE city_name = 'Monteria')
)
RETURNING supplier_id;

-- 3. Make sure the category exists (insert only if it is new)
INSERT INTO riwi_category (category_name)
VALUES ('Herramientas')
ON CONFLICT (category_name) DO NOTHING;

-- 4. Register the product associated with the new supplier
INSERT INTO riwi_product (product_name, category_id)
VALUES (
    'Taladro Percutor 1/2',
    (SELECT category_id FROM riwi_category WHERE category_name = 'Herramientas')
)
RETURNING product_id;

-- 5. Register the purchase that links the new supplier with the new product
INSERT INTO riwi_purchase (purchase_order_number, supplier_id, product_id, purchase_date, quantity, unit_price)
VALUES (
    'PO-2001',
    (SELECT supplier_id FROM riwi_supplier WHERE supplier_name = 'Ferreteria del Sinu S.A.S.'),
    (SELECT product_id FROM riwi_product WHERE product_name = 'Taladro Percutor 1/2'),
    CURRENT_DATE,
    50,
    215000.00
)
RETURNING purchase_id;
