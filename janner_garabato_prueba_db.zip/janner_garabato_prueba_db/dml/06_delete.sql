-- =====================================================================
-- RiwiSupply S.A.S. - Relational Database
-- Script: 06_delete.sql
-- Purpose: Delete a product that has no associated inventory movements
-- Engine: PostgreSQL
-- =====================================================================

-- 1. Register a demo product with no purchases and no movements,
--    so we have a safe candidate to delete.
INSERT INTO riwi_product (product_name, category_id)
VALUES (
    'Cinta Aislante 3M',
    (SELECT category_id FROM riwi_category WHERE category_name = 'Consumibles')
)
RETURNING product_id;

-- 2. Delete the product only if it has zero inventory movements
--    (this WHERE clause enforces the business rule; the FOREIGN KEY
--    constraints on riwi_inventory_movement / riwi_purchase are the
--    second line of defense that would reject the DELETE anyway if
--    the product were still in use).
DELETE FROM riwi_product
WHERE product_name = 'Cinta Aislante 3M'
  AND product_id NOT IN (SELECT DISTINCT product_id FROM riwi_inventory_movement);

-- 3. Verify the product no longer exists
SELECT * FROM riwi_product WHERE product_name = 'Cinta Aislante 3M';

-- ---------------------------------------------------------------------
-- Integrity demonstration (expected to FAIL on purpose):
-- Trying to delete a product that DOES have movements/purchases is
-- rejected by the foreign key constraints, protecting data integrity.
-- ---------------------------------------------------------------------
-- DELETE FROM riwi_product WHERE product_name = 'Guante de Nitrilo';
-- ERROR: update or delete on table "riwi_product" violates foreign key
-- constraint "fk_movement_product" on table "riwi_inventory_movement"
