-- =====================================================================
-- Consulta 6: Valor total del inventario almacenado por bodega
-- Necesidad del negocio: Como gerente de operaciones necesito conocer
-- el valor económico del inventario distribuido en cada bodega.
-- Logic: value = SUM(IN quantity * unit_price) - SUM(OUT quantity * unit_price)
-- =====================================================================

SELECT
    w.warehouse_id,
    w.warehouse_name,
    ci.city_name AS warehouse_city,
    COALESCE(SUM(CASE WHEN m.movement_type = 'IN'  THEN m.quantity * m.unit_price END), 0)
        - COALESCE(SUM(CASE WHEN m.movement_type = 'OUT' THEN m.quantity * m.unit_price END), 0)
        AS current_inventory_value
FROM riwi_warehouse w
JOIN riwi_city ci ON ci.city_id = w.city_id
LEFT JOIN riwi_inventory_movement m ON m.warehouse_id = w.warehouse_id
GROUP BY w.warehouse_id, w.warehouse_name, ci.city_name
ORDER BY current_inventory_value DESC;
