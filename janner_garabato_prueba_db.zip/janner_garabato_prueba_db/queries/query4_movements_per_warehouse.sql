-- =====================================================================
-- Consulta 4: Cantidad de movimientos registrados por bodega
-- Necesidad del negocio: Como administrador de operaciones necesito
-- conocer cuáles bodegas presentan mayor actividad.
-- =====================================================================

SELECT
    w.warehouse_id,
    w.warehouse_name,
    ci.city_name AS warehouse_city,
    COUNT(m.movement_id) AS total_movements,
    SUM(CASE WHEN m.movement_type = 'IN'  THEN 1 ELSE 0 END) AS in_movements,
    SUM(CASE WHEN m.movement_type = 'OUT' THEN 1 ELSE 0 END) AS out_movements
FROM riwi_warehouse w
JOIN riwi_city ci ON ci.city_id = w.city_id
LEFT JOIN riwi_inventory_movement m ON m.warehouse_id = w.warehouse_id
GROUP BY w.warehouse_id, w.warehouse_name, ci.city_name
ORDER BY total_movements DESC;
