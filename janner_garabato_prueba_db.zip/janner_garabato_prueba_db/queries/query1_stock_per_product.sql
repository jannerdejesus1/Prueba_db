-- =====================================================================
-- Consulta 1: Stock disponible por producto
-- Necesidad del negocio: Como encargado de inventarios necesito conocer
-- las existencias actuales de cada producto para planificar futuras
-- compras.
-- Logic: stock = SUM(quantity where movement_type = 'IN')
--              - SUM(quantity where movement_type = 'OUT')
-- =====================================================================

SELECT
    p.product_id,
    p.product_name,
    c.category_name,
    COALESCE(SUM(CASE WHEN m.movement_type = 'IN'  THEN m.quantity END), 0) AS total_in,
    COALESCE(SUM(CASE WHEN m.movement_type = 'OUT' THEN m.quantity END), 0) AS total_out,
    COALESCE(SUM(CASE WHEN m.movement_type = 'IN'  THEN m.quantity END), 0)
        - COALESCE(SUM(CASE WHEN m.movement_type = 'OUT' THEN m.quantity END), 0) AS available_stock
FROM riwi_product p
JOIN riwi_category c ON c.category_id = p.category_id
LEFT JOIN riwi_inventory_movement m ON m.product_id = p.product_id
GROUP BY p.product_id, p.product_name, c.category_name
ORDER BY available_stock DESC;
