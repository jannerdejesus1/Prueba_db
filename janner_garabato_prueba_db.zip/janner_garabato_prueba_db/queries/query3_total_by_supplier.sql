-- =====================================================================
-- Consulta 3: Total comprado por proveedor
-- Necesidad del negocio: Como responsable de compras necesito
-- identificar cuánto se ha comprado a cada proveedor.
-- =====================================================================

SELECT
    s.supplier_id,
    s.supplier_name,
    ci.city_name AS supplier_city,
    COUNT(pu.purchase_id)              AS purchase_orders,
    SUM(pu.quantity)                   AS total_units_purchased,
    SUM(pu.quantity * pu.unit_price)   AS total_amount_purchased
FROM riwi_supplier s
JOIN riwi_city ci ON ci.city_id = s.city_id
LEFT JOIN riwi_purchase pu ON pu.supplier_id = s.supplier_id
GROUP BY s.supplier_id, s.supplier_name, ci.city_name
ORDER BY total_amount_purchased DESC NULLS LAST;
