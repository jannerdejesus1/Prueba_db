-- =====================================================================
-- Consulta 5: Producto con mayor volumen de compras
-- Necesidad del negocio: Como analista necesito identificar cuál es el
-- producto que genera la mayor rotación dentro de la organización.
-- =====================================================================

SELECT
    p.product_id,
    p.product_name,
    cat.category_name,
    SUM(pu.quantity) AS total_units_purchased,
    SUM(pu.quantity * pu.unit_price) AS total_amount_purchased
FROM riwi_product p
JOIN riwi_category cat ON cat.category_id = p.category_id
JOIN riwi_purchase pu  ON pu.product_id = p.product_id
GROUP BY p.product_id, p.product_name, cat.category_name
ORDER BY total_units_purchased DESC
LIMIT 1;
