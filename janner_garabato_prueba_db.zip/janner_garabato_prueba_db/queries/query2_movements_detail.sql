-- =====================================================================
-- Consulta 2: Movimientos de inventario con detalle de producto y bodega
-- Necesidad del negocio: Como supervisor logístico necesito conocer los
-- movimientos realizados en cada bodega y los productos involucrados.
-- =====================================================================

SELECT
    m.movement_id,
    m.movement_date,
    w.warehouse_name,
    ci.city_name  AS warehouse_city,
    p.product_name,
    cat.category_name,
    m.movement_type,
    m.quantity,
    m.unit_price,
    (m.quantity * m.unit_price) AS total_value
FROM riwi_inventory_movement m
JOIN riwi_warehouse w ON w.warehouse_id = m.warehouse_id
JOIN riwi_city ci      ON ci.city_id = w.city_id
JOIN riwi_product p    ON p.product_id = m.product_id
JOIN riwi_category cat ON cat.category_id = p.category_id
ORDER BY m.movement_date, w.warehouse_name;
