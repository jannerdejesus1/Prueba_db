-- =====================================================================
-- RiwiSupply S.A.S. - Relational Database
-- Script: 03_load_data.sql
-- Purpose: Load cleaned/normalized data from CSV files using COPY
-- Engine: PostgreSQL
-- Run inside: bd_Janner_delahoz_garabato
-- Order matters because of foreign key dependencies:
--   city -> category -> supplier/warehouse/product -> purchase -> movement
-- Adjust the file paths below to match where the CSV files are stored
-- on the machine running psql.
-- =====================================================================

COPY riwi_city (city_id, city_name)
FROM '/absolute/path/to/data/riwi_city.csv'
DELIMITER ',' CSV HEADER;

COPY riwi_category (category_id, category_name)
FROM '/absolute/path/to/data/riwi_category.csv'
DELIMITER ',' CSV HEADER;

COPY riwi_supplier (supplier_id, supplier_name, city_id)
FROM '/absolute/path/to/data/riwi_supplier.csv'
DELIMITER ',' CSV HEADER;

COPY riwi_warehouse (warehouse_id, warehouse_name, city_id)
FROM '/absolute/path/to/data/riwi_warehouse.csv'
DELIMITER ',' CSV HEADER;

COPY riwi_product (product_id, product_name, category_id)
FROM '/absolute/path/to/data/riwi_product.csv'
DELIMITER ',' CSV HEADER;

COPY riwi_purchase (purchase_id, purchase_order_number, supplier_id, product_id, purchase_date, quantity, unit_price)
FROM '/absolute/path/to/data/riwi_purchase.csv'
DELIMITER ',' CSV HEADER;

COPY riwi_inventory_movement (movement_id, movement_date, warehouse_id, product_id, movement_type, quantity, unit_price, purchase_id)
FROM '/absolute/path/to/data/riwi_inventory_movement.csv'
DELIMITER ',' CSV HEADER
NULL AS '';

-- Re-sync sequences after loading explicit IDs
SELECT setval('riwi_city_city_id_seq', (SELECT MAX(city_id) FROM riwi_city));
SELECT setval('riwi_category_category_id_seq', (SELECT MAX(category_id) FROM riwi_category));
SELECT setval('riwi_supplier_supplier_id_seq', (SELECT MAX(supplier_id) FROM riwi_supplier));
SELECT setval('riwi_warehouse_warehouse_id_seq', (SELECT MAX(warehouse_id) FROM riwi_warehouse));
SELECT setval('riwi_product_product_id_seq', (SELECT MAX(product_id) FROM riwi_product));
SELECT setval('riwi_purchase_purchase_id_seq', (SELECT MAX(purchase_id) FROM riwi_purchase));
SELECT setval('riwi_inventory_movement_movement_id_seq', (SELECT MAX(movement_id) FROM riwi_inventory_movement));
