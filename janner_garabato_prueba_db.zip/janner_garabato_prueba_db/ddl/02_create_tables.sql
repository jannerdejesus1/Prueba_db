-- =====================================================================
-- RiwiSupply S.A.S. - Relational Database
-- Script: 02_create_tables.sql
-- Purpose: Create all tables (structure normalized up to 3NF)
-- Engine: PostgreSQL
-- Run inside: bd_Janner_delahoz_garabato
-- All table/column names in English, prefixed with riwi_
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. riwi_city
--    Independent entity. Removes the repetition/typos of city names
--    that used to live inside supplier and warehouse records
--    (e.g. "Cartagena", "Ctg", "Barranquilla", "B/quilla", "Sta Marta").
-- ---------------------------------------------------------------------
CREATE TABLE riwi_city (
    city_id     SERIAL PRIMARY KEY,
    city_name   VARCHAR(100) NOT NULL UNIQUE
);

-- ---------------------------------------------------------------------
-- 2. riwi_category
--    Independent entity. Removes repeated/misspelled category values
--    (e.g. "Herramienta" vs "Herramientas", "EPP" vs "Elementos Protección").
-- ---------------------------------------------------------------------
CREATE TABLE riwi_category (
    category_id     SERIAL PRIMARY KEY,
    category_name   VARCHAR(100) NOT NULL UNIQUE
);

-- ---------------------------------------------------------------------
-- 3. riwi_supplier
--    One row per real-world supplier (duplicates such as
--    "Aceros del Norte S.A.S", "Aceros del Norte", "ACEROS NORTE"
--    are consolidated into a single record).
-- ---------------------------------------------------------------------
CREATE TABLE riwi_supplier (
    supplier_id     SERIAL PRIMARY KEY,
    supplier_name   VARCHAR(150) NOT NULL UNIQUE,
    city_id         INTEGER NOT NULL,
    CONSTRAINT fk_supplier_city
        FOREIGN KEY (city_id) REFERENCES riwi_city (city_id)
);

-- ---------------------------------------------------------------------
-- 4. riwi_warehouse
--    One row per real-world warehouse (duplicates such as
--    "Bodega Central" and "Bod. Central" are consolidated).
-- ---------------------------------------------------------------------
CREATE TABLE riwi_warehouse (
    warehouse_id    SERIAL PRIMARY KEY,
    warehouse_name  VARCHAR(150) NOT NULL UNIQUE,
    city_id         INTEGER NOT NULL,
    CONSTRAINT fk_warehouse_city
        FOREIGN KEY (city_id) REFERENCES riwi_city (city_id)
);

-- ---------------------------------------------------------------------
-- 5. riwi_product
--    One row per real-world product (duplicates such as
--    "Disco de Corte 4.5" / "Disco Corte 4.5" and
--    "Guante Nitrilo" / "Guantes de Nitrilo" are consolidated).
--    Each product belongs to exactly one category (2FN/3FN: category
--    data does not repeat per product, it is referenced by FK).
-- ---------------------------------------------------------------------
CREATE TABLE riwi_product (
    product_id      SERIAL PRIMARY KEY,
    product_name    VARCHAR(150) NOT NULL UNIQUE,
    category_id     INTEGER NOT NULL,
    CONSTRAINT fk_product_category
        FOREIGN KEY (category_id) REFERENCES riwi_category (category_id)
);

-- ---------------------------------------------------------------------
-- 6. riwi_purchase
--    Represents a purchase made to a supplier (the "compras realizadas"
--    required by the business). Each purchase order number is unique
--    and is linked to exactly one supplier and one product.
-- ---------------------------------------------------------------------
CREATE TABLE riwi_purchase (
    purchase_id             SERIAL PRIMARY KEY,
    purchase_order_number   VARCHAR(20) NOT NULL UNIQUE,
    supplier_id             INTEGER NOT NULL,
    product_id              INTEGER NOT NULL,
    purchase_date           DATE NOT NULL,
    quantity                INTEGER NOT NULL CHECK (quantity > 0),
    unit_price              NUMERIC(12,2) NOT NULL CHECK (unit_price > 0),
    CONSTRAINT fk_purchase_supplier
        FOREIGN KEY (supplier_id) REFERENCES riwi_supplier (supplier_id),
    CONSTRAINT fk_purchase_product
        FOREIGN KEY (product_id) REFERENCES riwi_product (product_id)
);

-- ---------------------------------------------------------------------
-- 7. riwi_inventory_movement
--    Represents every IN/OUT stock movement per warehouse and product.
--    purchase_id is nullable: OUT movements (stock leaving the
--    warehouse) are not associated with a purchase order, only IN
--    movements coming from a supplier purchase are.
-- ---------------------------------------------------------------------
CREATE TABLE riwi_inventory_movement (
    movement_id     SERIAL PRIMARY KEY,
    movement_date   DATE NOT NULL,
    warehouse_id    INTEGER NOT NULL,
    product_id      INTEGER NOT NULL,
    movement_type   VARCHAR(3) NOT NULL CHECK (movement_type IN ('IN','OUT')),
    quantity        INTEGER NOT NULL CHECK (quantity > 0),
    unit_price      NUMERIC(12,2) NOT NULL CHECK (unit_price > 0),
    purchase_id     INTEGER NULL,
    CONSTRAINT fk_movement_warehouse
        FOREIGN KEY (warehouse_id) REFERENCES riwi_warehouse (warehouse_id),
    CONSTRAINT fk_movement_product
        FOREIGN KEY (product_id) REFERENCES riwi_product (product_id),
    CONSTRAINT fk_movement_purchase
        FOREIGN KEY (purchase_id) REFERENCES riwi_purchase (purchase_id)
);

-- Helpful indexes for reporting queries
CREATE INDEX idx_movement_product   ON riwi_inventory_movement (product_id);
CREATE INDEX idx_movement_warehouse ON riwi_inventory_movement (warehouse_id);
CREATE INDEX idx_purchase_supplier  ON riwi_purchase (supplier_id);
CREATE INDEX idx_purchase_product   ON riwi_purchase (product_id);
