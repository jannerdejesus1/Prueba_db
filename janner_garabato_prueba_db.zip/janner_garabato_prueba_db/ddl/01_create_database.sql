-- =====================================================================
-- RiwiSupply S.A.S. - Relational Database
-- Script: 01_create_database.sql
-- Purpose: Create the database
-- Engine: PostgreSQL
-- Naming convention: bd_<firstname>_<lastname>_<clan>
-- =====================================================================

DROP DATABASE IF EXISTS bd_Janner_delahoz_garabato;
CREATE DATABASE bd_Janner_delahoz_garabato;

-- Connect to the new database before running 02_create_tables.sql
-- \c bd_Janner_delahoz_garabato
